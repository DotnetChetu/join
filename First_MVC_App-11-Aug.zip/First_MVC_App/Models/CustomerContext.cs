﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace First_MVC_App.Models
{
    public class CustomerContext:DbContext
    {

        public CustomerContext() : base("cnn") { }

        public DbSet<customer> Customers { get; set; }
        public DbSet<Department> Departments { get; set; }
        public DbSet<Address> Addresses { get; set; }

      
    }
}