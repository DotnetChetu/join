﻿using First_MVC_App.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using First_MVC_App.ViewModel;
namespace First_MVC_App.Controllers
{
    public class Customer2Controller : Controller
    {
        private CustomerContext context;
        public Customer2Controller()
        {
            context = new CustomerContext();
        }
        // GET: Customer2
        public ActionResult Index()
        {
            var depts = context.Departments.ToList();
            return View(depts);
        }

        public ActionResult Customers(int id)
        {
            // var emps = context.Customers.Where(e => e.Department.Id == id);
            //return View(emps);

            var emps = (from c in context.Customers where         c.Department.Id == id
                       join
                       d in context.Departments
                       on c.Department.Id equals d.Id 
                       join
                       add in context.Addresses 
                       on c.Id equals add.Customer.Id
                       select new CustomerViewModel()
                       {
                        Id=c.Id,
                        Name=c.Name,
                        Mobile=c.Mobile,
                        Email=c.Email,
                        Gender=c.Gender,
                        Dept=d.Name,
                        street=add.Street,
                        House=add.HouseNo,
                        PinCode=add.PinCode
                       }).ToList();

            return View(emps);



        }
    }
}