﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using First_MVC_App.Models;
namespace First_MVC_App.Controllers
{
    public class CustomerController : Controller
    {
        // GET: Customer
        private CustomerContext context;
        public CustomerController()
        {
            context = new CustomerContext();
        }
        public ActionResult Index()
        {
            //var customers = new List<string>()
            //{
            //    "Ajay",
            //    "vijay",
            //    "sonu",
            //    "deepak"
            //};
            //ViewBag.customers = customers;
            //ViewData["customers"] = customers;
            List<customer> obj = context.Customers.ToList();
            return View(obj);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(customer customer)
        {
            context.Customers.Add(customer);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            if (context.Customers.Any(e => e.Id == id))
            {
                var cust = context.Customers.SingleOrDefault(e => e.Id == id);
                context.Customers.Remove(cust);
                context.SaveChanges();
                ViewBag.msg = "customer deleted successfully..";
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.msg = "customer not found";
                return RedirectToAction("Index");
            }
        }

        public ActionResult Edit(int id)
        {
            var cust = context.Customers.SingleOrDefault(e => e.Id == id);
            return View(cust);
        }

        [HttpPost]
        public ActionResult Update(customer customer)
        {
            context.Entry(customer).State = System.Data.Entity.EntityState.Modified;
            context.SaveChanges();
            return RedirectToAction("Index");
        }

    }
}